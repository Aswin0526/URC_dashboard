from src.serial_writer import SerialObject()


object = SerialObject()

while True:
    object.write(0,0)

